﻿using System;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassLibrary1.Numbers numbers = new ClassLibrary1.Numbers();
            numbers.PrintEtryingNumber();
            Console.ReadKey();
        }
    }
}
